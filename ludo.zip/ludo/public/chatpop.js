
function openForm() {
  document.getElementById("chatBoxDiv").style.display = "block";
  document.getElementById("closeButton").style.display = "block";
  document.getElementById("openButton").style.display = "none";
}

function closeForm() {
  document.getElementById("chatBoxDiv").style.display = "none";
  document.getElementById("closeButton").style.display = "none";
  document.getElementById("openButton").style.display = "block";
}
